package com.example.calculojuros;

import android.app.Activity;

public class ResultadoActivity extends Activity {
}
